package com.grupo4.ecosoft;

import java.util.Scanner;

import com.grupo4.ecosoft.service.AutenticacionService;

/**
 * Clase principal que demuestra el funcionamiento de los módulos
 * de inicio de sesión y registro
 */
public class Main {
    
    private static final AutenticacionService autenticacionService = new AutenticacionService();
    private static final Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        boolean salir = false;
        
        while (!salir) {
            mostrarMenu();
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    iniciarSesion();
                    break;
                case 2:
                    registrarUsuario();
                    break;
                case 3:
                    salir = true;
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
        
        scanner.close();
    }
    
    private static void mostrarMenu() {
        System.out.println("\n===== EcoSoft - Grupo 4 =====");
        System.out.println("1. Iniciar sesión");
        System.out.println("2. Registrarse");
        System.out.println("3. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    private static int leerOpcion() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    private static void iniciarSesion() {
        System.out.println("\n----- Inicio de Sesión -----");
        System.out.print("Nombre de usuario: ");
        String nombreUsuario = scanner.nextLine();
        
        System.out.print("Contraseña: ");
        String password = scanner.nextLine();
        
        String resultado = autenticacionService.iniciarSesion(nombreUsuario, password);
        System.out.println(resultado);
    }
    
    private static void registrarUsuario() {
        System.out.println("\n----- Registro de Usuario -----");
        System.out.print("Nombre de usuario: ");
        String nombreUsuario = scanner.nextLine();
        
        System.out.print("Contraseña: ");
        String password = scanner.nextLine();
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        String resultado = autenticacionService.registrarUsuario(nombreUsuario, password, email);
        System.out.println(resultado);
    }
}

