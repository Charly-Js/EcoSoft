package com.grupo4.ecosoft.service;

import com.grupo4.ecosoft.dao.UsuarioDAO;
import com.grupo4.ecosoft.model.Usuario;

/**
 * Servicio que maneja la lógica de autenticación y registro de usuarios
 */
public class AutenticacionService {
    
    private final UsuarioDAO usuarioDAO;
    
    public AutenticacionService() {
        this.usuarioDAO = new UsuarioDAO();
    }
    
    /**
     * Realiza el inicio de sesión de un usuario
     * @param nombreUsuario El nombre de usuario
     * @param password La contraseña
     * @return Un mensaje indicando el resultado del inicio de sesión
     */
    public String iniciarSesion(String nombreUsuario, String password) {
        if (nombreUsuario == null || nombreUsuario.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            return "Error: Nombre de usuario y contraseña son requeridos";
        }
        
        boolean credencialesValidas = usuarioDAO.validarCredenciales(nombreUsuario, password);
        
        if (credencialesValidas) {
            return "Inicio de sesión exitoso para el usuario: " + nombreUsuario;
        } else {
            return "Error: Usuario no existe o contraseña incorrecta";
        }
    }
    
    /**
     * Registra un nuevo usuario en el sistema
     * @param nombreUsuario El nombre de usuario
     * @param password La contraseña
     * @param email El correo electrónico
     * @return Un mensaje indicando el resultado del registro
     */
    public String registrarUsuario(String nombreUsuario, String password, String email) {
        // Validaciones básicas
        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) {
            return "Error: Nombre de usuario es requerido";
        }
        
        if (password == null || password.trim().isEmpty()) {
            return "Error: Contraseña es requerida";
        }
        
        if (email == null || email.trim().isEmpty() || !email.contains("@")) {
            return "Error: Email inválido";
        }
        
        // Verificar si el usuario ya existe
        if (usuarioDAO.existeUsuario(nombreUsuario)) {
            return "Error: El usuario ya está registrado en la base de datos";
        }
        
        // Crear y guardar el nuevo usuario
        Usuario nuevoUsuario = new Usuario(nombreUsuario, password, email);
        boolean registroExitoso = usuarioDAO.guardarUsuario(nuevoUsuario);
        
        if (registroExitoso) {
            return "Usuario registrado exitosamente";
        } else {
            return "Error al registrar el usuario";
        }
    }
}

