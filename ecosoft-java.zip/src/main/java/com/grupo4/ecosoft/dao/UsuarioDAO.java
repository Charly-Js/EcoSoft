package com.grupo4.ecosoft.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.grupo4.ecosoft.config.HibernateUtil;
import com.grupo4.ecosoft.model.Usuario;

public class UsuarioDAO {
    
    /**
     * Guarda un nuevo usuario en la base de datos
     * @param usuario El usuario a guardar
     * @return true si se guardó correctamente, false en caso contrario
     */
    public boolean guardarUsuario(Usuario usuario) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(usuario);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Busca un usuario por su nombre de usuario
     * @param nombreUsuario El nombre de usuario a buscar
     * @return El usuario encontrado o null si no existe
     */
    public Usuario buscarPorNombreUsuario(String nombreUsuario) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Usuario> query = session.createQuery("FROM Usuario WHERE nombreUsuario = :nombreUsuario", Usuario.class);
            query.setParameter("nombreUsuario", nombreUsuario);
            return query.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Verifica si existe un usuario con el nombre de usuario y contraseña proporcionados
     * @param nombreUsuario El nombre de usuario
     * @param password La contraseña
     * @return true si las credenciales son válidas, false en caso contrario
     */
    public boolean validarCredenciales(String nombreUsuario, String password) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Usuario> query = session.createQuery(
                "FROM Usuario WHERE nombreUsuario = :nombreUsuario AND password = :password", 
                Usuario.class
            );
            query.setParameter("nombreUsuario", nombreUsuario);
            query.setParameter("password", password);
            return query.uniqueResult() != null;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Verifica si ya existe un usuario con el nombre de usuario proporcionado
     * @param nombreUsuario El nombre de usuario a verificar
     * @return true si ya existe, false en caso contrario
     */
    public boolean existeUsuario(String nombreUsuario) {
        return buscarPorNombreUsuario(nombreUsuario) != null;
    }
}

