package com.grupo4.ecosoft.config;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.grupo4.ecosoft.model.Usuario;

public class HibernateUtil {
    private static final SessionFactory sessionFactory = buildSessionFactory();
    
    private static SessionFactory buildSessionFactory() {
        try {
            // Create the SessionFactory from hibernate.cfg.xml
            Configuration configuration = new Configuration();
            configuration.configure("hibernate.cfg.xml");
            
            // Add entity classes
            configuration.addAnnotatedClass(Usuario.class);
            
            return configuration.buildSessionFactory();
        } catch (Throwable ex) {
            System.err.println("Initial SessionFactory creation failed: " + ex);
            throw new ExceptionInInitializer(ex);
        }
    }
    
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
    
    public static void shutdown() {
        // Close caches and connection pools
        getSessionFactory().close();
    }
    
    private static class ExceptionInInitializer extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public ExceptionInInitializer(Throwable cause) {
            super(cause);
        }
    }
}

