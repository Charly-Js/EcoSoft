-- Script para la creación de la base de datos EcoSoft
-- Desarrollado por Grupo 4

-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS ecosoft_db;

-- Usar la base de datos
USE ecosoft_db;

-- Crear tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar algunos usuarios de prueba
INSERT INTO usuarios (nombre_usuario, password, email) VALUES
('admin', 'admin123', 'admin@ecosoft.com'),
('usuario1', 'pass123', 'usuario1@ejemplo.com');

-- Mostrar la estructura de la tabla
DESCRIBE usuarios;

-- Mostrar los usuarios insertados
SELECT * FROM usuarios;

